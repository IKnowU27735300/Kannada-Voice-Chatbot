import React from 'react';
import { ConnectionState } from '../types';

interface ControlsProps {
  connectionState: ConnectionState;
  onConnect: () => void;
  onDisconnect: () => void;
}

export const Controls: React.FC<ControlsProps> = ({ connectionState, onConnect, onDisconnect }) => {
  const isConnected = connectionState === ConnectionState.CONNECTED;
  const isConnecting = connectionState === ConnectionState.CONNECTING;

  if (isConnected) {
    return (
      <div className="flex items-center justify-center gap-6 z-10">
        <button
          onClick={onDisconnect}
          className="group relative flex items-center justify-center w-16 h-16 rounded-full bg-red-500/10 hover:bg-red-500/20 border border-red-500/50 transition-all duration-300 backdrop-blur-sm"
          title="End Conversation"
        >
          <div className="w-6 h-6 bg-red-500 rounded-sm shadow-[0_0_15px_rgba(239,68,68,0.5)] group-hover:scale-110 transition-transform" />
        </button>
        <div className="absolute bottom-24 text-slate-400 text-sm font-medium tracking-wide animate-pulse">
          Listening...
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-4 z-10">
      <button
        onClick={onConnect}
        disabled={isConnecting}
        className={`
          relative group px-8 py-4 rounded-full 
          bg-gradient-to-r from-violet-600 to-indigo-600 
          text-white font-semibold text-lg tracking-wide shadow-lg shadow-indigo-500/30
          hover:shadow-indigo-500/50 hover:scale-105 active:scale-95 transition-all duration-300
          disabled:opacity-70 disabled:cursor-not-allowed disabled:hover:scale-100
        `}
      >
        {isConnecting ? (
          <span className="flex items-center gap-2">
            <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Connecting...
          </span>
        ) : (
          <span className="flex items-center gap-2">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
            Start Conversation
          </span>
        )}
        
        {/* Button Glow Effect */}
        <div className="absolute inset-0 rounded-full bg-white/20 blur-md opacity-0 group-hover:opacity-100 transition-opacity" />
      </button>
      
      {!isConnecting && (
        <p className="text-slate-400 text-sm">
          Powered by Gemini 2.5 Flash • Live API
        </p>
      )}
    </div>
  );
};