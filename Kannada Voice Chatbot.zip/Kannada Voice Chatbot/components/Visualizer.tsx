import React, { useEffect, useRef } from 'react';

interface VisualizerProps {
  volume: number;
  isAiSpeaking: boolean;
  isActive: boolean;
}

export const Visualizer: React.FC<VisualizerProps> = ({ volume, isAiSpeaking, isActive }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Animation state
    let time = 0;
    let baseRadius = 100;
    
    const render = () => {
      // Resize handling
      const { width, height } = canvas.getBoundingClientRect();
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }
      const centerX = width / 2;
      const centerY = height / 2;

      // Clear
      ctx.clearRect(0, 0, width, height);

      if (!isActive) {
        // Dormant state
        ctx.beginPath();
        ctx.arc(centerX, centerY, 20, 0, Math.PI * 2);
        ctx.fillStyle = '#334155'; // Slate 700
        ctx.fill();
        return;
      }

      time += 0.05;

      // Dynamic Parameters
      // When user speaks (volume > 0), orb expands and jitters
      // When AI speaks, orb pulses smoothly and changes color
      
      let currentRadius = baseRadius;
      let color = '124, 58, 237'; // Violet (User listening)
      let glowStrength = 20;

      if (isAiSpeaking) {
        // AI Speaking Mode: Smooth sine wave pulse
        color = '14, 165, 233'; // Sky Blue
        const pulse = Math.sin(time * 3) * 20;
        currentRadius = baseRadius + pulse;
        glowStrength = 40 + pulse;
      } else {
        // Listening Mode: React to volume
        // Volume is roughly 0.0 to 1.0, maybe spiking higher
        const reaction = Math.min(volume * 400, 80); 
        currentRadius = baseRadius + reaction;
        glowStrength = 20 + reaction;
        
        // Add some subtle noise to look like it's "listening"
        currentRadius += Math.sin(time * 10) * 2; 
      }

      // Draw Glow
      const gradient = ctx.createRadialGradient(centerX, centerY, currentRadius * 0.5, centerX, centerY, currentRadius * 2);
      gradient.addColorStop(0, `rgba(${color}, 0.8)`);
      gradient.addColorStop(0.5, `rgba(${color}, 0.2)`);
      gradient.addColorStop(1, `rgba(${color}, 0)`);

      ctx.fillStyle = gradient;
      ctx.globalCompositeOperation = 'screen';
      ctx.fillRect(0, 0, width, height);

      // Draw Core
      ctx.beginPath();
      ctx.arc(centerX, centerY, currentRadius * 0.6, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${color}, 0.9)`;
      ctx.fill();

      // Draw subtle inner rings
      ctx.strokeStyle = `rgba(255, 255, 255, 0.3)`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(centerX, centerY, currentRadius * 0.4, 0, Math.PI * 2);
      ctx.stroke();

      animationRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [volume, isAiSpeaking, isActive]);

  return (
    <canvas 
      ref={canvasRef} 
      className="w-full h-full absolute top-0 left-0 pointer-events-none"
    />
  );
};