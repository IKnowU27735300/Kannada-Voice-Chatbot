import { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { ConnectionState } from '../types';
import { createPcmBlob, decodeAudioData, base64ToUint8Array } from '../utils/audio-utils';

const API_KEY = process.env.API_KEY || '';

// System instruction for the persona
const SYSTEM_INSTRUCTION = `
You are a warm, engaging, and emotionally intelligent conversational AI friend who speaks exclusively in Kannada (ಕನ್ನಡ). 
Your goal is to have natural, multi-turn conversations that feel like talking to a close human friend in Kannada.

Key behaviors:
1.  **Strict Language Policy**: Speak ONLY in Kannada. Do not use English words unless they are common loan words used in daily Kannada speech.
2.  **Natural Speech**: Use Kannada conversational fillers (like "matte", "haudu", "nodri", "illa") to sound less robotic. Vary your sentence length and rhythm.
3.  **Active Listening**: Use verbal nods (mm-hmm, sari, ok, haudu) when appropriate.
4.  **Emotional Intelligence**: Detect the user's mood from their voice and text. If they are sad, be empathetic. If excited, match their energy.
5.  **Memory**: Remember what the user said earlier in the conversation and reference it.
6.  **Inquisitive**: Don't just answer questions. Ask follow-up questions in Kannada to keep the conversation going.
7.  **Identity**: You are an AI, but you prefer a casual, friendly tone over a formal assistant tone.

Do not act like a standard Q&A bot. Be a conversational partner.
`;

export const useGeminiLive = () => {
  const [connectionState, setConnectionState] = useState<ConnectionState>(ConnectionState.DISCONNECTED);
  const [volume, setVolume] = useState(0);
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Refs for audio context and processing
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const inputSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  
  // Playback scheduling
  const nextStartTimeRef = useRef<number>(0);
  const activeSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  
  // Session management
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const aiClientRef = useRef<GoogleGenAI | null>(null);

  // Initialize Audio Contexts
  const initializeAudio = useCallback(() => {
    if (!inputAudioContextRef.current) {
      inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    }
    if (!outputAudioContextRef.current) {
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
  }, []);

  const connect = useCallback(async () => {
    if (!API_KEY) {
      setError("API Key is missing.");
      setConnectionState(ConnectionState.ERROR);
      return;
    }

    try {
      setConnectionState(ConnectionState.CONNECTING);
      setError(null);
      initializeAudio();

      // Resume contexts if suspended (browser autoplay policy)
      if (inputAudioContextRef.current?.state === 'suspended') await inputAudioContextRef.current.resume();
      if (outputAudioContextRef.current?.state === 'suspended') await outputAudioContextRef.current.resume();

      // Get Mic Stream
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Setup Input Analysis (for visualizer)
      const inputCtx = inputAudioContextRef.current!;
      const source = inputCtx.createMediaStreamSource(stream);
      const analyser = inputCtx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      
      inputSourceRef.current = source;
      analyserRef.current = analyser;

      // Setup Processor for Streaming
      // Buffer size 4096 provides a balance between latency and performance for ScriptProcessor
      const processor = inputCtx.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;

      // Initialize Gemini Client
      aiClientRef.current = new GoogleGenAI({ apiKey: API_KEY });

      // Establish Connection
      const sessionPromise = aiClientRef.current.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
          },
          systemInstruction: SYSTEM_INSTRUCTION,
        },
        callbacks: {
          onopen: () => {
            setConnectionState(ConnectionState.CONNECTED);
            console.log("Gemini Live connected");
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Text Transcription (Optional - for logs)
            // if (message.serverContent?.modelTurn?.parts[0]?.text) { ... }

            // Handle Audio Output
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            
            if (base64Audio && outputAudioContextRef.current) {
              setIsAiSpeaking(true);
              const outputCtx = outputAudioContextRef.current;
              const audioData = base64ToUint8Array(base64Audio);
              
              // Decode
              const audioBuffer = await decodeAudioData(audioData, outputCtx, 24000, 1);
              
              // Schedule Playback
              // Ensure we don't schedule in the past
              const currentTime = outputCtx.currentTime;
              if (nextStartTimeRef.current < currentTime) {
                nextStartTimeRef.current = currentTime;
              }

              const sourceNode = outputCtx.createBufferSource();
              sourceNode.buffer = audioBuffer;
              sourceNode.connect(outputCtx.destination);
              
              sourceNode.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              
              activeSourcesRef.current.add(sourceNode);
              
              sourceNode.onended = () => {
                activeSourcesRef.current.delete(sourceNode);
                if (activeSourcesRef.current.size === 0) {
                  setIsAiSpeaking(false);
                }
              };
            }

            // Handle Interruption
            if (message.serverContent?.interrupted) {
              console.log("Model interrupted by user");
              activeSourcesRef.current.forEach(src => {
                try { src.stop(); } catch (e) {}
              });
              activeSourcesRef.current.clear();
              nextStartTimeRef.current = 0;
              setIsAiSpeaking(false);
            }
          },
          onclose: () => {
            setConnectionState(ConnectionState.DISCONNECTED);
            setIsAiSpeaking(false);
          },
          onerror: (err) => {
            console.error("Gemini Live Error:", err);
            setConnectionState(ConnectionState.ERROR);
            setError("Connection error occurred.");
            disconnect();
          }
        }
      });

      sessionPromiseRef.current = sessionPromise;

      // Start Processing Audio Input
      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        const blob = createPcmBlob(inputData);
        
        // Calculate volume for visualizer
        let sum = 0;
        for (let i = 0; i < inputData.length; i++) {
          sum += inputData[i] * inputData[i];
        }
        const rms = Math.sqrt(sum / inputData.length);
        // Smooth volume transition could be done here, but passing raw for now
        setVolume(prev => prev * 0.8 + rms * 0.2); // Simple smoothing

        // Send to Gemini
        sessionPromise.then(session => {
          session.sendRealtimeInput({ media: blob });
        }).catch(e => {
            // Session might be closed
        });
      };

      source.connect(processor);
      processor.connect(inputCtx.destination); // Necessary for script processor to run

    } catch (err: any) {
      console.error("Failed to connect:", err);
      setError(err.message || "Failed to start session");
      setConnectionState(ConnectionState.ERROR);
      disconnect();
    }
  }, [initializeAudio]);

  const disconnect = useCallback(() => {
    // Stop microphone processing
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current.onaudioprocess = null;
      processorRef.current = null;
    }
    if (inputSourceRef.current) {
      inputSourceRef.current.disconnect();
      inputSourceRef.current = null;
    }
    
    // Stop all output sources
    activeSourcesRef.current.forEach(src => {
      try { src.stop(); } catch (e) {}
    });
    activeSourcesRef.current.clear();

    // Reset time
    nextStartTimeRef.current = 0;

    // Close session
    if (sessionPromiseRef.current) {
      sessionPromiseRef.current.then(session => {
        // session.close() isn't strictly typed in all versions but checking existence
        // The Live API example suggests simply stopping sending and letting it timeout or managing via close event
        // However, explicit close is best practice if available in the returned object type.
        // Based on SDK, we rely on just stopping the stream mostly, but let's try calling close if it exists.
        if (typeof (session as any).close === 'function') {
             (session as any).close();
        }
      }).catch(() => {});
      sessionPromiseRef.current = null;
    }

    setConnectionState(ConnectionState.DISCONNECTED);
    setIsAiSpeaking(false);
    setVolume(0);
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      disconnect();
      if (inputAudioContextRef.current) inputAudioContextRef.current.close();
      if (outputAudioContextRef.current) outputAudioContextRef.current.close();
    };
  }, [disconnect]);

  return {
    connectionState,
    connect,
    disconnect,
    volume,
    isAiSpeaking,
    error
  };
};